# IntelliS
IntelliS is a health management system which is developed by incorporating a machine learning solution into a software system. The system is intended to be used in the hospital where it can help tremendously reduce the workload of doctors by helping diagnose patients.
